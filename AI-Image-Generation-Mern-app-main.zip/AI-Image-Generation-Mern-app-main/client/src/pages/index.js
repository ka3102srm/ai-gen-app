import CreatePost from "./CreatePost";
import Home from "./Home";

export { Home, CreatePost };
